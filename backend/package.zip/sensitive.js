module.exports = {
  password: '0QBq58conoYgnAmu',
  userid: 'Lando2',
  salt: '4!8Dy7fzQL_`[3E%(hs(y.]L+bhNk/2x'
};
